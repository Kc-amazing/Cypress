interface Window {
  // @ts-ignore
  Cypress: Cypress.Cypress;
  store: Record<string, any>;
}
