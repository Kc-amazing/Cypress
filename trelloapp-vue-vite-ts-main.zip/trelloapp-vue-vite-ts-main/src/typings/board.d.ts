interface Board {
  id: number;
  starred: boolean;
  name: string;
  created: string;
  user: number;
}

export default Board;
