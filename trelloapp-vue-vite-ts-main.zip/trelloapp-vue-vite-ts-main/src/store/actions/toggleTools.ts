export const toggleTools = async function (this: any, flag: boolean) {
  this.showTools = flag;
};
