export const toggleSearch = async function (this: any, flag: boolean) {
  this.showSearch = flag;
  this.searchResults = [];
};
