export const blurInput = (event: Event) => {
  (event.target as HTMLInputElement).blur();
};
