export const selectInput = (event: Event) => {
  (event.target as HTMLInputElement).select();
};
