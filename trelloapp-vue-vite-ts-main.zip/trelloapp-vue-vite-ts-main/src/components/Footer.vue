<template>
  <a
    data-cy="footer-link"
    class="fixed bottom-2 w-full text-xs text-center text-blue10 opacity-75"
    href="https://filiphric.com"
  >
    ...powered by coffee and love ❤️&nbsp;&nbsp;Filip Hric
  </a>
</template>
