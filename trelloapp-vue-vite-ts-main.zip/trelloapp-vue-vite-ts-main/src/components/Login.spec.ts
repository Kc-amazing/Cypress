import Login from '@/components/Login.vue';

it('shows login', () => {
  cy.mount(Login);
});
