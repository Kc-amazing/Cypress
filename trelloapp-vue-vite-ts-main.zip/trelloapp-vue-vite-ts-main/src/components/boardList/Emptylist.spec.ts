import Emptylist from '@/components/boardList/Emptylist.vue';

it('shows empty list', () => {
  cy.mount(Emptylist);
});
