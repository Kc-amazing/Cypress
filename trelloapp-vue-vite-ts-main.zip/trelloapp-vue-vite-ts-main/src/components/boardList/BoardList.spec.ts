import BoardList from '@/components/boardList/BoardList.vue';

it('mounts', () => {
  cy.mount(BoardList);
});
