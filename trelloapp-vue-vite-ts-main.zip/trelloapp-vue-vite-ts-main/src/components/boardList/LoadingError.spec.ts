import LoadingError from '@/components/boardList/LoadingError.vue';

it('shows loading error', () => {
  cy.mount(LoadingError);
});
