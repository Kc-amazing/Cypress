import Loading from '@/components/Loading.vue';

it('shows loading', () => {
  cy.mount(Loading);
});
