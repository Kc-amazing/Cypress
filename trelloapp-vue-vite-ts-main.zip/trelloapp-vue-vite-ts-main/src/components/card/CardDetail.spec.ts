import CardDetail from '@/components/card/CardDetail.vue';

it('shows card detail', () => {
  cy.mount(CardDetail);
});
