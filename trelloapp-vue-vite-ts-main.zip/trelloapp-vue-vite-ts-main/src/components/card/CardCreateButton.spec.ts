import CardCreateButton from '@/components/card/CardCreateButton.vue';

it('shows card create button', () => {
  cy.mount(CardCreateButton);
});
