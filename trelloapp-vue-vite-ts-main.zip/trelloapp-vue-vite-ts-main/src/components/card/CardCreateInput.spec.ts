import CardCreateInput from '@/components/card/CardCreateInput.vue';

it('shows card create input', () => {
  cy.mount(CardCreateInput);
});
