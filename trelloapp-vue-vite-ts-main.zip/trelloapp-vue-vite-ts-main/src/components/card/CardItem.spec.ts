import CardItem from '@/components/card/CardItem.vue';

it('shows card item', () => {
  cy.mount(CardItem);
});
