import ListCreate from '@/components/list/ListCreate.vue';

it('shows list create button', () => {
  cy.mount(ListCreate);
});
