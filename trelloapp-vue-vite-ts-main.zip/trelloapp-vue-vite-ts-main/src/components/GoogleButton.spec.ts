import GoogleButton from '@/components/GoogleButton.vue';

it('shows google button', () => {
  cy.mount(GoogleButton);
});
