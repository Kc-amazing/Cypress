import NotFound from '@/components/NotFound.vue';

it('shows not found page', () => {
  cy.mount(NotFound);
});
