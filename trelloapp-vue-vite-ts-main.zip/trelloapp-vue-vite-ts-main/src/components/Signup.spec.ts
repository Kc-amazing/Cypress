import Signup from '@/components/Signup.vue';

it('shows signup', () => {
  cy.mount(Signup);
});
