import Dropzone from '@/components/Dropzone.vue';

it('shows Dropzone', () => {
  cy.mount(Dropzone);
});
