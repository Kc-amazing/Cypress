import BoardDetail from '@/components/board/BoardDetail.vue';

it('shows BoardDetail', () => {
  cy.mount(BoardDetail);
});
