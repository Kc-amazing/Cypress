import BoardItem from '@/components/board/BoardItem.vue';

it('shows checkbox', () => {
  cy.mount(BoardItem);
});
