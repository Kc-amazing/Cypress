import Checkbox from '@/components/Checkbox.vue';

it('shows checkbox', () => {
  cy.mount(Checkbox);
});
