import LoginButton from '@/components/LoginButton.vue';

it('shows login button', () => {
  cy.mount(LoginButton);
});
