import { getDataCy } from '@commands/getDataCy'

Cypress.Commands.add('getDataCy', getDataCy);